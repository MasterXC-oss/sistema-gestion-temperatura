from ProyectoAndroid.app import main

if __name__ == "__main__":
    main().main_loop()
